    
/**
 * Vytvorenie plochy kde sa zobrazia ovce, vlci, graf a tlačítko na ovladanie, pri spustení následne sa ovce a vlci pohybujú 
 * 
 * @author (Michal Čekan) 
 * @version (2.1)
 */

import java.util.Random;
import fri.shapesge.Obdlznik;
import fri.shapesge.Manazer;
import java.util.ArrayList;

import fri.shapesge.BlokTextu;
import fri.shapesge.StylFontu;

public class Simulation {
    private Manazer manazer;
    private int x;
    private int y;
    private int mouseX;
    private int mouseY;
    private int sheepBreed;
    private int wolfBreed;
    private boolean start;

    private BlokTextu pocetOviecText;
    private BlokTextu pocetVlkovText;

    private Obdlznik grafOhranicenie1;
    private Obdlznik grafOhranicenie2;
    private Obdlznik grafOhranicenie3;
    private Obdlznik grafOhranicenie4;

    private Obdlznik tlacitko;
    private BlokTextu textTlacitka;

    private ArrayList<Sheep> listOviec;
    private ArrayList<Wolf> listVlkov;

    private ArrayList<Obdlznik> grafOvca;
    private ArrayList<Obdlznik> grafVlk;
    private int pocetTik;
    
    /**
     * @param sheepNum zadajte počet oviec na začiatku simulácie
     * @param sheepBreedChance šanca na rozmnožovanie oviec
     * @param wolfNum zadajte počet vlkov na začiatku simulácie
     * @param wolfBreedChance šanca na rozmnožovanie vlkov
     */
    
    public Simulation(int sheepNum, int sheepBreedChance, int wolfNum, int wolfBreedChance, boolean running) {
        this.pozadie();
        this.sheepBreed = sheepBreedChance;
        this.wolfBreed = wolfBreedChance;
        this.listOviec = new ArrayList<>();
        this.listVlkov = new ArrayList<>();

        this.start = running;
        for (int i = 0; i < sheepNum; i++) {
            Sheep ovca = new Sheep(this.getRandomX(), this.getRandomY(), sheepBreedChance, running);
            this.listOviec.add(ovca);
            Thread sheepThread = new Thread(ovca);
            sheepThread.start();
        }

        for (int i = 0; i < wolfNum; i++) {
            Wolf vlk = new Wolf(this.getRandomX(), this.getRandomY(), wolfBreedChance, running);
            this.listVlkov.add(vlk);
            Thread wolfThread = new Thread(vlk);
            wolfThread.start();
        }

        //https://www.javatpoint.com/java-int-to-string

        this.pocetOviecText = new BlokTextu("Počet Oviec: " + Integer.toString(this.listOviec.size()), 550, 100);
        this.pocetOviecText.zmenFont("Times New Roman", StylFontu.BOLD, 25);
        this.pocetOviecText.zobraz();
        this.pocetVlkovText = new BlokTextu("Počet Vlkov: " + Integer.toString(this.listVlkov.size()), 750, 100);
        this.pocetVlkovText.zmenFont("Times New Roman", StylFontu.BOLD, 25);
        this.pocetVlkovText.zobraz();
        this.manazer = new Manazer();
        this.manazer.spravujObjekt(this);
        this.grafOhranicenie();
        this.button();
        this.grafOvca = new ArrayList<>();
        this.grafVlk = new ArrayList<>();
    }

    public void tik() {
        if (this.start) {
            this.reproductionOfSheep();
            this.reproductionOfWolf();
            this.wolfEatingSheep();
            this.starvingWolf();
            this.pocetOviecText.zmenText("Počet Oviec: " + Integer.toString(this.listOviec.size()));
            this.pocetVlkovText.zmenText("Počet Vlkov: " + Integer.toString(this.listVlkov.size()));
            this.graf();

        }
    }

    
    public void aktivuj() {
        
        /**
         * čítanie z klávesnice, stláčením medzerníka vieme spustiť aj stopnúť simuláciu
         */ 
        this.start = !this.start;
        if (this.start) {
            this.tlacitko.zmenFarbu("red");
            this.textTlacitka.zmenText("Stop");
            this.textTlacitka.zmenPolohu(700, 510);
        } else {
            this.tlacitko.zmenFarbu("green");
            this.textTlacitka.zmenText("Continue");
            this.textTlacitka.zmenPolohu(650, 510);
        }

        for (Sheep i : this.listOviec) {
            i.running(this.start);
        }
        for (Wolf i : this.listVlkov) {
            i.running(this.start);
        }

    }

    public void grafOhranicenie() {
        /**
         * Vytvorenie grafické ohraničenie grafu
         */
         
        this.grafOhranicenie1 = new Obdlznik();
        this.grafOhranicenie1.zmenFarbu("black");
        this.grafOhranicenie1.zmenStrany(400, 5);
        this.grafOhranicenie1.zmenPolohu(550, 650);
        this.grafOhranicenie1.zobraz();

        this.grafOhranicenie2 = new Obdlznik();
        this.grafOhranicenie2.zmenFarbu("black");
        this.grafOhranicenie2.zmenStrany(5, 300);
        this.grafOhranicenie2.zmenPolohu(550, 650);
        this.grafOhranicenie2.zobraz();

        this.grafOhranicenie3 = new Obdlznik();
        this.grafOhranicenie3.zmenFarbu("black");
        this.grafOhranicenie3.zmenStrany(405, 5);
        this.grafOhranicenie3.zmenPolohu(550, 950);
        this.grafOhranicenie3.zobraz();

        this.grafOhranicenie4 = new Obdlznik();
        this.grafOhranicenie4.zmenFarbu("black");
        this.grafOhranicenie4.zmenStrany(5, 300);
        this.grafOhranicenie4.zmenPolohu(950, 650);
        this.grafOhranicenie4.zobraz();

        for (int i = 0; i <= 300; i += 100) {
            BlokTextu cisla = new BlokTextu(Integer.toString(i), 525, 955 - i);
            cisla.zobraz();
        }
    }

    public void button() {
        /**
         * vytvorenie tlačitka
         */ 
        this.tlacitko = new Obdlznik();
        this.tlacitko.zmenFarbu("green");
        this.tlacitko.zmenPolohu(625, 400);
        this.tlacitko.zmenStrany(250, 200);
        this.tlacitko.zobraz();

        this.textTlacitka = new BlokTextu("Start", 700, 510);
        this.textTlacitka.zmenFont("Times New Roman", StylFontu.BOLD, 50);
        this.textTlacitka.zobraz();
    }

    public void vyberSuradnice(int x, int y) {
        /**
         * Ziskanie x a y suradnice stlačenia miše, následne skontroluje ak je stlačené na súradniciach kde je tlačitko tak zavola funkciu aktivuj()
         */ 
        if (x > 625 && 875 > x && y > 400 && 600 > y) {
            this.aktivuj();
        }
    }

    public void graf() {
        
        /**
         * graf počtu oviec a vlkoc v závislosti tikov
         */ 
        
        if (this.listOviec.size() != 0) {
            Obdlznik obdlznikOvca = new Obdlznik();
            obdlznikOvca.zmenPolohu(555 + this.pocetTik, 951 - this.listOviec.size());
            obdlznikOvca.zmenFarbu("blue");
            obdlznikOvca.zmenStrany(1, 1);
            obdlznikOvca.zobraz();
            this.grafOvca.add(obdlznikOvca);
            int j = 0;   
            if (this.pocetTik >= 395) {
                for (Obdlznik i : this.grafOvca) {
                    j++;
                    if (j == 1) {
                        i.skry();
                    }
                    i.posunVodorovne(-1);
                }
                this.grafOvca.remove(0);
            }
        }

        if (this.listVlkov.size() != 0) {
            Obdlznik obdlznikVlk = new Obdlznik();
            obdlznikVlk.zmenPolohu(555 + this.pocetTik, 951 - this.listVlkov.size());
            obdlznikVlk.zmenFarbu("red");
            obdlznikVlk.zmenStrany(1, 1);
            obdlznikVlk.zobraz();
            this.grafVlk.add(obdlznikVlk);
            int j = 0;
            if (this.pocetTik >= 395) {
                for (Obdlznik i : this.grafVlk) {
                    j++;
                    if (j == 1) {
                        i.skry();
                    }
                    i.posunVodorovne(-1);
                }
                this.grafVlk.remove(0);
            }
        }
        if (this.pocetTik < 400) {
            this.pocetTik++;
        } else {
            this.pocetTik = 400;
        }
    }

    public int getRandomX() {
        /**
         * @return vráti nahodnú súradnicu X typu int
         */ 
        Random random = new Random();
        int pomocne = 0;
        pomocne = (random.nextInt(500));
        this.x = pomocne;
        return pomocne;
    }

    public int getRandomY() {
        /**
         * @return vráti nahodnú súradnicu Y typu int
         */ 
        Random random = new Random();
        int pomocne = 0;
        pomocne = (random.nextInt(1000));
        this.y = pomocne;
        return pomocne;
    }

    public void pozadie() {
        
        /**
         * vytvorenie zeleneho pozadia
         */
        Obdlznik trava = new Obdlznik();
        trava.zmenFarbu("#7CFC00");
        trava.posunVodorovne(-60);
        trava.posunZvisle(-50);
        trava.zmenStrany(500, 1000);
        trava.zobraz();
    }

    public void reproductionOfSheep() {
        /**
         * rozmnožovanie oviec, ak sú dve ovce blízko seba pričom jedna je ovca a druha je baran tak sa rozmnožia
         */ 
        if (this.sheepBreed != 0 && this.listOviec.size() <= 250 && this.listOviec.size() != 0) {
            Random random = new Random();
            ArrayList<Sheep> pomocne = new ArrayList();
            for (Sheep sheep1 : this.listOviec) {
                for (Sheep sheep2 : this.listOviec) {
                    if (sheep1 != sheep2) {
                        if (sheep1.getX() + 30 > sheep2.getX() && sheep1.getX() < sheep2.getX() && sheep1.getY() + 30 > sheep2.getY() && sheep1.getY() < sheep2.getY()) {
                            if (sheep1.getGender().equals("male") && sheep2.getGender().equals("female") || sheep1.getGender().equals("female") && sheep2.getGender().equals("male")) {
                                int chance = random.nextInt(100);
                                if (chance < this.sheepBreed) {
                                    int newX = (sheep1.getX() + sheep2.getX()) / 2 + random.nextInt(10) - 5;
                                    int newY = (sheep1.getY() + sheep2.getY()) / 2 + random.nextInt(10) - 5;

                                    if (pomocne.size() + this.listOviec.size() < 250) { 
                                        Sheep ovca = new Sheep(newX, newY, this.sheepBreed, this.start);
                                        pomocne.add(ovca);
                                        Thread sheepThread = new Thread(ovca);
                                        sheepThread.start();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for (Sheep i : pomocne) {
                this.listOviec.add(i);
            }
            this.pocetOviecText.zmenText(Integer.toString(this.listOviec.size()));
        }
    }

    public void reproductionOfWolf() {
        /**
         * rozmnožovanie vlkov, ak sú blízko seba pričom jeden je vlk a druhý vlk je vlčica
         */
        if (this.wolfBreed != 0 && this.listVlkov.size() <= 250 && this.listVlkov.size() != 0) {
            Random random = new Random();
            ArrayList<Wolf> pomocne = new ArrayList();
            for (Wolf wolf1 : this.listVlkov) {
                for (Wolf wolf2 : this.listVlkov) {
                    if (wolf1 != wolf2) {
                        if (wolf1.getX() + 30 > wolf2.getX() && wolf1.getX() < wolf2.getX() && wolf1.getY() + 30 > wolf2.getY() && wolf1.getY() < wolf2.getY()) {
                            if (wolf1.getGender().equals("male") && wolf2.getGender().equals("female") || wolf1.getGender().equals("female") && wolf2.getGender().equals("male")) {
                                int chance = random.nextInt(100);
                                if (chance < this.sheepBreed) {
                                    int newX = (wolf1.getX() + wolf2.getX()) / 2 + random.nextInt(10) - 5;
                                    int newY = (wolf1.getY() + wolf2.getY()) / 2 + random.nextInt(10) - 5;
                                    if (pomocne.size() + this.listVlkov.size() < 250) {
                                        Wolf vlk = new Wolf(newX, newY, this.wolfBreed, this.start);
                                        pomocne.add(vlk);
                                        Thread wolfThread = new Thread(vlk);
                                        wolfThread.start();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for (Wolf i : pomocne) {
                this.listVlkov.add(i);
            }
            this.pocetVlkovText.zmenText(Integer.toString(this.listVlkov.size()));
        }
    }

    public void wolfEatingSheep() {
        /**
         * logika ak vlk zje ovcu tak ovca zahinie a vlk sa naje (bude žiť dlhšie)
         */ 
        ArrayList<Sheep> pomocne = new ArrayList();
        ArrayList<Wolf> pomocne2 = new ArrayList();
        for (Wolf wolf : this.listVlkov) {
            for (Sheep sheep : this.listOviec) {
                if (wolf.getX() + 30 > sheep.getX() && wolf.getX() < sheep.getX() && wolf.getY() + 30 > sheep.getY() && wolf.getY() < sheep.getY()) {
                    pomocne.add(sheep);
                    pomocne2.add(wolf);
                }
            }
        }
        for (Sheep i : pomocne) {
            i.odstranOvcu();
            this.listOviec.remove(i);
        }
        for (Wolf i : pomocne2) {
            i.eating();
        }
        this.pocetOviecText.zmenText(Integer.toString(this.listOviec.size()));
    }

    public void starvingWolf() {
        /**
         * ak vlk nieje najedený tak zahinie
         */ 
        ArrayList<Wolf> pomocne = new ArrayList();
        for (Wolf wolf : this.listVlkov) {
            if (wolf.getStarving() == 0) {
                pomocne.add(wolf);
            }
        }
        for (Wolf i : pomocne) {
            this.listVlkov.remove(i);
            i.deleteWolf();
        }
    }

}
