
/**
 * SheepWolf Simulation
 * 
 * @author (Michal Čekan) 
 * @version (2.1)
 */

import fri.shapesge.Obrazok;
import java.util.Random;
import javax.swing.Timer;
import fri.shapesge.Manazer;

public class Wolf implements Runnable {
    private int x;
    private int y;
    private int velocity = 5;
    private int breed;
    private String gender;
    private Obrazok obrazok;
    private Timer timer;
    private Manazer manazer;
    private boolean start;
    private int starving = 60;
    private boolean hasEaten;
    private Vector vector;
    private double speedX;
    private double speedY;

    /**
     * @param x počiatočná pozicia X
     * @param y počiatočná pozicia Y
     * @param breedChance šanca na rozmnoženie, 0 až 100
     * @param start dá vedieť či sa ma objekt už pohybovať
     */
    public Wolf(int x, int y, int breedChance, boolean start) {
        Random random = new Random();
        int pomocne = random.nextInt(2);
        if (pomocne == 0) {
            this.gender = "female";
            this.obrazok = new Obrazok("pics//wolf.jpg");
        } else {
            this.gender = "male";
            this.obrazok = new Obrazok("pics//wolf.jpg");
        }

        this.x = x;
        this.y = y;
        this.breed = breedChance;

        this.obrazok.posunVodorovne(-100);
        this.obrazok.posunZvisle(-100);
        this.start = start;
        this.obrazok.posunVodorovne(x);
        this.obrazok.posunZvisle(y);
        this.obrazok.zobraz();
        this.manazer = new Manazer();
        this.manazer.spravujObjekt(this);
    }
    
    /**
     * dá vedieť objektu či sa už môže hybať
     */
    public void running(boolean start) {
        this.start = start;
    }

    
    /**
     * Zabezpečuje pohyb vlkov
     */
    @Override
    public void run() {
        while (true) {
            if (this.start) {
                this.move();
            }

            try {
                Thread.sleep(75);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    
    /**
     * pohyb vlkov a otočenia ich k danému smeru
     */ 
    private void move() {
        Random random = new Random();
        int x2 = (random.nextInt(100) - 50);
        int y2 = (random.nextInt(100) - 50);
        Vector vector = new Vector(this.x, this.y, x2, y2);
        int steps = 100;
        int[] pozicia = vector.heading();
        double deltaX = pozicia[0];
        double deltaY = pozicia[1];

        this.speedX = (deltaX * this.velocity) / steps;
        this.speedY = (deltaY * this.velocity) / steps;
        for (int i = 0; i <= steps; i++) {
            synchronized (this) {
                if (this.start) {
                    if (this.x + this.speedX > 500 || this.x + this.speedX < 0) {
                        this.speedX = -this.speedX;
                    }

                    if (this.y + this.speedY > 1000 || this.y + this.speedY < 0) {
                        this.speedY = -this.speedY;
                    }

                    this.x += (int)Math.round(this.speedX);
                    this.y += (int)Math.round(this.speedY);

                    this.obrazok.posunVodorovne((int)Math.round(this.speedX));
                    this.obrazok.posunZvisle((int)Math.round(this.speedY));
                    this.rotate(this.x + (int)this.speedX, this.y + (int)this.speedY);
                }
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * @param x2 pozicia kde bude vlk smerovať
     * @param y2 pozicia kde bude vlk smerovať
     */
    public void rotate(int x2, int y2) {
        Vector vector = new Vector(this.x, this.y, x2, y2);
        int[] pomocne = vector.heading();
        this.obrazok.zmenUhol(vector.direction());
    }

    /**
     * @return vráti poziciu X typu int
     */
    public int getX() {
        return this.x;
    }

    /**
     * @return vráti poziciu Y typu int
     */
    public int getY() {
        return this.y;
    }

    /**
     * @return vráti text pohlavia vlka
     */
    public String getGender() {
        return this.gender;
    }

    /**
     * @return vrati hodnotu koľko tikov bude ešte vlk žiť
     */
    public int getStarving() {
        this.starving--;
        return this.starving;
    }
    
    /**
     * ak vlk zjedol ovcu, zavola sa tato funkcia a sa mu zvíši jedlo
     */
    public void eating() {
        this.starving += 20;
    }

    /**
     * odstrani vlka
     */
    public void deleteWolf() {
        this.obrazok.skry();
    }

}
