
/**
 * Main class cez ktorá číta počet Oviec a Vlkov zo súbora a následne vytvorí Simuláciu
 * 
 * @author Michal Čekan
 * @version 2.1
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
// https://www.w3schools.com/java/java_files_read.asp

public class Main {

    
    /**
     * čitanie zo súbora "settings.txt" a nasledne spustenie simulacie pod+la parametrov
     */
    
    public static void main(String[] args)  throws FileNotFoundException {
        int pocetOvci = 0;
        int sancaNaRozmnozenieOviec = 0;
        int pocetVlkov = 0;
        int sancaNaRozmnozenieVlkov = 0;
        try (Scanner scanner = new Scanner(new File("settings.txt"))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();

                String[] parts = line.split("=");
                String variable = parts[0].trim();
                if (parts.length == 2) {
                    switch (variable) {
                        case "pocetOvci":
                            pocetOvci = Integer.parseInt(parts[1].trim());
                            continue;
                        case "sancaNaRozmnozenieOviec":
                            sancaNaRozmnozenieOviec = Integer.parseInt(parts[1].trim());
                            continue;
                        case "pocetVlkov":
                            pocetVlkov = Integer.parseInt(parts[1].trim());
                            continue;
                        default:
                            sancaNaRozmnozenieVlkov = Integer.parseInt(parts[1].trim());
                    }
                    
                } else {
                    System.out.println("Invalid format: " + line);
                }
            }

            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + "settings.txt");
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.out.println("Error parsing integer value.");
            e.printStackTrace();
        }
        Simulation simulation = new Simulation(pocetOvci, sancaNaRozmnozenieOviec, pocetVlkov, sancaNaRozmnozenieVlkov, false);
    }
    
    
}
