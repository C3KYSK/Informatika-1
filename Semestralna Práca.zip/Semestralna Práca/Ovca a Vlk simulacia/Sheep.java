
/**
 * 
 * 
 * @author (Michal Čekan) 
 * @version (2.1)
 */

import fri.shapesge.Obrazok;
import java.util.Random;
import fri.shapesge.Manazer;

public class Sheep implements Runnable {
    private int x;
    private int y;
    private int velocity = 3;
    private int breed;
    private String gender;
    private Obrazok obrazok;
    private Manazer manazer;
    private boolean start;
    private Vector vector;
    private double speedX;
    private double speedY;

    /**
     * @param x počiatočná pozicia X
     * @param y počiatočná pozicia Y
     * @param breedChance šanca na rozmnoženie, 0 až 100
     * @param start dá vedieť či sa ma objekt už pohybovať
     */
    public Sheep(int x, int y, int breedChance, boolean start) {
        Random random = new Random();
        int pomocne = random.nextInt(2);
        if (pomocne == 0) {

            //link of picture sheep
            // https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.pinterest.com%2Fpin%2Fsheep-pixel-art-in-2023--102738435241862429%2F&psig=AOvVaw3SEYdCS74veGuW8YSFrvA_&ust=1703271511305000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCPi19_6aoYMDFQAAAAAdAAAAABAD
            this.gender = "female";
            this.obrazok = new Obrazok("pics//sheep.jpg");
        } else {
            this.gender = "male";
            // link of picture ram
            // https://www.google.com/url?sa=i&url=https%3A%2F%2Fstock.adobe.com%2Fimages%2Faries-zodiac-sign-icon-8-bit-pixel-art-ram-isolated-on-white-background-astrological-symbol-esoteric-science-logo-horoscope-emblem%2F226620487&psig=AOvVaw0YxUe_edp2E4_Qc6kYTqvP&ust=1703270398049000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCMjFy--WoYMDFQAAAAAdAAAAABAD
            this.obrazok = new Obrazok("pics//ram.jpg");
        }

        this.start = start;

        this.x = x;
        this.y = y;
        this.breed = breedChance;

        this.obrazok.posunVodorovne(-100);
        this.obrazok.posunZvisle(-100);

        this.obrazok.posunVodorovne(x);
        this.obrazok.posunZvisle(y);
        this.obrazok.zobraz();

        this.manazer = new Manazer();
        this.manazer.spravujObjekt(this);
    }

    /**
     * dá vedieť objektu či sa už môže hybať
     */
    public void running(boolean start) {
        this.start = start;
    }

    
    /**
     * Zabezpečuje pohyb oviec
     */
    @Override
    public void run() {
        while (true) {
            if (this.start) {
                this.move();
            }
            try {
                Thread.sleep(150);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void move() {
        /**
         * pohyb ovcí a otočenia ich k danému smeru
         */ 
        Random random = new Random();
        int x2 = (random.nextInt(100) - 50);
        int y2 = (random.nextInt(100) - 50);

        Vector vector = new Vector(this.x, this.y, x2, y2);
        int steps = 100;
        int[] pozicia = vector.heading();
        double deltaX = pozicia[0];
        double deltaY = pozicia[1];

        this.speedX = (deltaX * this.velocity) / steps;
        this.speedY = (deltaY * this.velocity) / steps;
        for (int i = 0; i <= steps; i++) {
            synchronized (this) {
                if (this.start) {
                    if (this.x + this.speedX > 500 || this.x + this.speedX < 0) {
                        this.speedX = -this.speedX;
                    }

                    if (this.y + this.speedY > 1000 || this.y + this.speedY < 0) {
                        this.speedY = -this.speedY;
                    }

                    this.x += (int)Math.round(this.speedX);
                    this.y += (int)Math.round(this.speedY);

                    this.obrazok.posunVodorovne((int)Math.round(this.speedX));
                    this.obrazok.posunZvisle((int)Math.round(this.speedY));
                    this.rotate(this.x + (int)this.speedX, this.y + (int)this.speedY);
                }
            }

            // pohyb ovce každých 0.1 sekund
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @param x2 pozicia kde bude ovca smerovať
     * @param y2 pozicia kde bude ovca smerovať
     */
    public void rotate(int x2, int y2) {
        // otočenie obrazka pomocou vypoćitaneho uhla
        Vector vector = new Vector(this.x, this.y, x2, y2);
        int[] pomocne = vector.heading();
        this.obrazok.zmenUhol(vector.direction());
    }

    /**
     * @return vráti poziciu X typu int
     */
    public int getX() {
        // ziskanie polohy X
        return this.x;
    }

    /**
     * @return vráti poziciu Y typu int
     */
    public int getY() {
        //ziskanie polohy Y
        return this.y;
    }

    /**
     * @return vráti text pohlavia ovce
     */
    public String getGender() {
        // ziskanie pohlavia oviec
        return this.gender;
    }

    /**
     * odstrani ovcu
     */
    public void odstranOvcu() {
        // odstraní obrazok ovce
        this.obrazok.skry();
    }

}
