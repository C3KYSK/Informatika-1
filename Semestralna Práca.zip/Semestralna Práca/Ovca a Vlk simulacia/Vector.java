
/**
 * Trieda napomahajúca počitania smeru, zdialenosti a uhla objektov
 * @author Michal Čekan 
 * @version 2.1
 */

// https://www.void1gaming.com/post/fundamentals-of-vector-math-in-game-development
public class Vector {

    private int aX;
    private int aY;
    private int bX;
    private int bY;

    /**
     * @param aX aktualna poloha X
     * @param aY aktualna poloha Y
     * @param bX nasledujuca poloha X
     * @param bY nasledujuca poloha Y
     */

    public Vector(int aX, int aY, int bX, int bY) {
        this.aX = aX;
        this.aY = aY;
        this.bX = bX;
        this.bY = bY;
    }

    /**
     * @return vráti hodnoty X a Y v liste ktorým smerom bude vektor smerovať
     */
    public int[] heading() {

        int[] smer = new int[2];
        int pomocneX = this.aX - this.bX;
        int pomocneY = this.aY - this.bY;

        smer[0] = pomocneX;
        smer[1] = pomocneY;

        return smer;
    }
    /**
     * @return vráti hodnotu vzdialenosti vektora
     */
    public double distance() {
        //vypočitanie vzdialenosti
        int[] pomocne = this.heading();
        double a = Math.sqrt(Math.pow(pomocne[0], 2) + Math.pow(pomocne[1], 2));
        return a;
    }
    
    /**
     * @return vráti hodnotu uhla vektora
     */
    public int direction() {
        //vypočitanie uhla
        if (this.bY - this.aY != 0 || this.bX - this.aX != 0) {
            double x = this.bX - this.aX;
            double y = this.bY - this.aY;
            double pomocne = Math.atan(x / y);
            double stupne = pomocne * (180 / Math.PI);
            return (int)-stupne + 90;
        }
        return 0;
    }

}
